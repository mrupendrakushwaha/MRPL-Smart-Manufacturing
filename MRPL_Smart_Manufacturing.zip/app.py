
import streamlit as st
import sqlite3
import pandas as pd

# ==========================================
# PAGE CONFIG
# ==========================================

st.set_page_config(
    page_title="MRPL Smart Manufacturing System",
    page_icon="🏭",
    layout="wide"
)

# ==========================================
# DATABASE
# ==========================================

DB_PATH = "mrpl.db"

def get_connection():
    return sqlite3.connect(DB_PATH)

def load_data(table):
    conn = get_connection()
    df = pd.read_sql_query(f"SELECT * FROM {table}", conn)
    conn.close()
    return df

# ==========================================
# HEADER
# ==========================================

st.title("🏭 MRPL Smart Manufacturing System")
st.caption("Smart Manufacturing & Quality Management System")

# ==========================================
# SIDEBAR
# ==========================================

st.sidebar.title("📋 Navigation")

menu = st.sidebar.radio(
    "Select Module",
    [
        "📊 Dashboard",
        "🧱 Raw Materials",
        "🏭 Production",
        "🧪 Quality Control",
        "📦 Finished Goods",
        "🚚 Orders & Dispatch"
    ]
)

# ==========================================
# DASHBOARD
# ==========================================

if menu == "📊 Dashboard":

    st.header("📊 Management Dashboard")

    raw_materials = load_data("raw_materials")
    production = load_data("production")
    finished_goods = load_data("finished_goods")
    orders = load_data("orders")
    dispatch = load_data("dispatch")

    low_stock = 0

    if not raw_materials.empty:
        low_stock = len(
            raw_materials[
                raw_materials["current_stock"]
                <= raw_materials["minimum_stock"]
            ]
        )

    col1, col2, col3 = st.columns(3)

    col1.metric("🧱 Raw Materials", len(raw_materials))
    col2.metric("🏭 Production", len(production))
    col3.metric("📦 Finished Goods", len(finished_goods))

    col4, col5, col6 = st.columns(3)

    col4.metric("📝 Orders", len(orders))
    col5.metric("🚚 Dispatches", len(dispatch))
    col6.metric("⚠️ Low Stock", low_stock)

    st.divider()

    if not production.empty:
        st.subheader("🏭 Production Overview")

        production_chart = production.groupby(
            "status"
        )["actual_quantity"].sum()

        st.bar_chart(production_chart)

    if not orders.empty:
        st.subheader("📝 Order Status")

        order_chart = orders["status"].value_counts()

        st.bar_chart(order_chart)

# ==========================================
# RAW MATERIALS
# ==========================================

elif menu == "🧱 Raw Materials":

    st.header("🧱 Raw Material Management")

    df = load_data("raw_materials")

    if df.empty:
        st.info("No raw material records available.")
    else:
        st.dataframe(
            df,
            use_container_width=True
        )

# ==========================================
# PRODUCTION
# ==========================================

elif menu == "🏭 Production":

    st.header("🏭 Production Management")

    df = load_data("production")

    if df.empty:
        st.info("No production records available.")
    else:
        st.dataframe(
            df,
            use_container_width=True
        )

# ==========================================
# QUALITY CONTROL
# ==========================================

elif menu == "🧪 Quality Control":

    st.header("🧪 Quality Control")

    df = load_data("quality_control")

    if df.empty:
        st.info("No quality control records available.")
    else:
        st.dataframe(
            df,
            use_container_width=True
        )

# ==========================================
# FINISHED GOODS
# ==========================================

elif menu == "📦 Finished Goods":

    st.header("📦 Finished Goods / Warehouse")

    df = load_data("finished_goods")

    if df.empty:
        st.info("No finished goods records available.")
    else:
        st.dataframe(
            df,
            use_container_width=True
        )

# ==========================================
# ORDERS & DISPATCH
# ==========================================

elif menu == "🚚 Orders & Dispatch":

    st.header("🚚 Orders & Dispatch")

    st.subheader("📝 Orders")

    orders = load_data("orders")

    if orders.empty:
        st.info("No order records available.")
    else:
        st.dataframe(
            orders,
            use_container_width=True
        )

    st.subheader("🚚 Dispatch")

    dispatch = load_data("dispatch")

    if dispatch.empty:
        st.info("No dispatch records available.")
    else:
        st.dataframe(
            dispatch,
            use_container_width=True
        )
